# ShortLoop+ v5.5

![Logo](icon128.png)

**Smart YouTube Shorts Scroller**

-  Automatically scrolls to the next Short when the video ends
-  Works across **Chrome**, **Brave**, **Edge**, **Firefox** (via MV2 support)

---

### Installation

1. Unzip this folder
2. Open your browser’s extensions page:
   - Chrome/Brave: `chrome://extensions`
   - Firefox: `about:debugging#/runtime/this-firefox`
   - Edge: `edge://extensions`
3. Enable **Developer Mode**
4. Click **Load Unpacked** and select the extracted folder

### COMMON ERROR FIX !!
IF THE EXTENTION DOSEN'T WORK FOLLOW THESE STEPS...
1. CLICK ON SHORTS BUTTON.
2. REFRESH THE PAGE 
3. THAT'S IT ....
4. ENJOY



---

### Credits
Made by **Atsukii**

---

More features coming soon.